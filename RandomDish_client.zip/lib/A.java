// 예시 메뉴 카드
SizedBox(height: 20),
buildFoodCard('토스트', '간단하고 달콤한 메뉴', 'assets/image/bad/토스트.jpg'),
SizedBox(height: 20),
buildFoodCard('떡국', '따뜻하고 든든한 한 그릇', 'assets/image/bad/떡국.jpg'),
SizedBox(height: 20),
buildFoodCard('죽', '속을 따뜻하게 해주는 음식', 'assets/image/bad/죽.jpg'),
SizedBox(height: 20),
buildFoodCard('똥', '속을 따뜻하게 해주는 음식', 'assets/image/bad/죽.jpg'),