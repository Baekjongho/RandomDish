import 'package:flutter/material.dart';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:typed_data';

void main() {
  runApp(MyApp());
}

List<String> resultNames=['','','','',''];
List<String> resultDescriptions=['','','','',''];
List<String> resultImagePaths=['https://via.placeholder.com/120x120','https://via.placeholder.com/120x120','https://via.placeholder.com/120x120','https://via.placeholder.com/120x120','https://via.placeholder.com/120x120'];
var count=-1;

List<String> bestNames = [
  '스테이크 & 와인', '랍스터', '초밥 오마카세', '트러플 크림 리조또', '대게찜',
  '양갈비', '한정식 코스', '와규 샤브샤브', '뷔페', '밀푀유 나베'
];
List<String> bestDescriptions = [
  '스테이크에 와인 한 잔으로 분위기 UP.', '버터에 구워진 랍스터는 완벽한 선택.', '셰프 추천 메뉴로 즐기는 고급 스시.',
  '트러플 향이 아는 이탈리아 요리.', '신선한 대게의 단맛과 부드러운 식감.', '풍미 가득한 양고기 스테이크.',
  '한국 전통의 격조 높은 요리.', '고급 소고기로 즐기는 일본식 샤브샤브.', '다양한 음식을 마음껏 즐길 수 있는 고급 뷔페에서의 만찬.',
  '고기와 채소를 층층이 쌓은 일본식 요리.'
];
List<String> bestImagePaths = [
  'assets/image/best/스테이크&와인.jpg', 'assets/image/best/랍스터.jpg', 'assets/image/best/초밥오마카세.jpg',
  'assets/image/best/트러플크림리조또.jpg', 'assets/image/best/대게찜.jpg', 'assets/image/best/양갈비.jpg',
  'assets/image/best/한정식 코스.jpg', 'assets/image/best/와규 샤브샤브.jpg', 'assets/image/best/뷔페.jpg',
  'assets/image/best/밀푀유나베.jpg'
];

// good
List<String> goodNames = [
  '피자 & 파스타', '치킨', '돈가스', '분식세트', '불고기 덮밥',
  '냉면', '햄버거 세트', '타코 & 나쵸', '삼겹살', '우동'
];
List<String> goodDescriptions = [
  '부담 없이 즐기는 이탈리안 음식.', '양념, 프라이드 등 기분 좋을 때 더 맛있게 먹을 수 있는 음식.', '겉바속촉의 일본식 요리.',
  '국민 간식 콤보!.', '고소한 맛이 기분을 더 좋게 만들어 줌.', '시원하고 깔끔한 맛.', '패티와 바삭한 감자튀김이 완벽한 조합.',
  '멕시코 스타일의 즐거운 음식.', '친구들과 함께 즐기는 고기의 풍미.', '뜨끈하고 짭조름한 일본식 면 요리.'
];
List<String> goodImagePaths = [
  'assets/image/good/피자&파스타.jpg', 'assets/image/good/치킨.jpg', 'assets/image/good/돈가스.jpg',
  'assets/image/good/분식세트.jpg', 'assets/image/good/불고기 덮밥.jpg', 'assets/image/good/냉면.jpg',
  'assets/image/good/햄버거 세트.jpg', 'assets/image/good/타코 & 나쵸.jpg', 'assets/image/good/삼겹살.jpg',
  'assets/image/good/우동.jpg'
];

// soso
List<String> sosoNames = [
  '김치찌개', '된장찌개', '비빔밥', '치킨마요 덮밥', '짜장면',
  '샌드위치', '순댓국', '라면', '김치볶음밥', '닭갈비'
];
List<String> sosoDescriptions = [
  '뜨끈하고 깊은 맛이 마음을 따뜻하게.', '한국인의 소울푸드.', '다채로운 색감으로 하루에 생기를 더함.',
  '간단하면서도 든든한 한 끼.', '맛있고 대중적인 중식.', '간단하게 즐길 수 있는 한 끼.',
  '진한 국물 요리로 속을 든든하게.', '간단하지만 만족스러운 선택.', '볶음 김치와 밥이 어우러진 간단한 한 끼.',
  '매콤한 양념에 볶은 닭고기와 채소 요리.'
];
List<String> sosoImagePaths = [
  'assets/image/soso/김치찌개.jpg', 'assets/image/soso/된장찌개.jpg', 'assets/image/soso/비빔밥.jpg',
  'assets/image/soso/치킨마요 덮밥.jpg', 'assets/image/soso/짜장면.jpg', 'assets/image/soso/샌드위치.jpg',
  'assets/image/soso/순댓국.jpg', 'assets/image/soso/라면.jpg', 'assets/image/soso/김치볶음밥.jpg',
  'assets/image/soso/닭갈비.jpg'
];

// bad
List<String> badNames = [
  '죽', '삼계탕', '카레', '떡국', '팟타이',
  '오므라이스', '순두부찌개', '토스트', '카스테라 & 우유', '따뜻한 차와 과자'
];
List<String> badDescriptions = [
  '속을 따뜻하게 해주는 부드러운 음식.', '몸과 마음을 달래주는 보양식.', '향긋하고 달콤한 맛으로 기분 전환.',
  '따뜻하고 든든한 한 그릇.', '부드럽고 달콤한 태국 요리.', '부드러운 달걀과 케첩이 위로를 줌.',
  '부드럽고 따뜻한 국물 요리.', '간단하면서 달콤하게 즐길 수 있는 메뉴.', '폭신폭신한 식감으로 편안한 느낌.',
  '마음의 안정을 위한 티타임.'
];
List<String> badImagePaths = [
  'assets/image/bad/죽.jpg', 'assets/image/bad/삼계탕.jpg', 'assets/image/bad/카레.jpg',
  'assets/image/bad/떡국.jpg', 'assets/image/bad/팟타이.jpg', 'assets/image/bad/오므라이스.jpg',
  'assets/image/bad/순두부찌개.jpg', 'assets/image/bad/토스트.jpg', 'assets/image/bad/카스테라 & 우유.jpg',
  'assets/image/bad/따뜻한 차와 과자.jpg'
];

// terrible
List<String> terribleNames = [
  '소고기미역국', '설렁탕', '계란찜', '바나나 & 우유', '콩나물국밥',
  '콘스프', '요거트 볼', '마라탕', '짬뽕', '불족발'
];
List<String> terribleDescriptions = [
  '담백하고 깔끔한 맛으로 속을 풀어줌.', '사골 국물에 밥을 곁들여 든든한 한 끼.', '촉촉하고 부드러운 맛으로 편안함.',
  '소화가 잘 되며 스트레스에 큰 효과!', '개운한 국물로 속을 풀어주는 전통 음식.', '따뜻하고 달콤한 맛의 간단한 음식.',
  '건강하면서도 상쾌한 느낌을 주는 음식.', '얼얼하고 깊은 맛으로 스트레스를 날려주는 중국식 매운탕.', '진한 국물과 매운맛이 어우러져 스트레스를 풀기에 딱 좋은 메뉴.',
  '족발에 매운 양념을 더해 쫄깃한 식감과 매운맛을 함께 즐김.'
];
List<String> terribleImagePaths = [
  'assets/image/terrible/소고기 미역국.jpg', 'assets/image/terrible/설렁탕.jpg', 'assets/image/terrible/계란찜.jpg',
  'assets/image/terrible/바나나 & 우유.jpg', 'assets/image/terrible/콩나물국밥.jpg', 'assets/image/terrible/콘스프.jpg',
  'assets/image/terrible/요거트 볼.jpg', 'assets/image/terrible/마라탕.jpg', 'assets/image/terrible/짬뽕.jpg',
  'assets/image/terrible/불족발.jpg'
];

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 20),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,

            children: [
              const SizedBox(width: 25),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultPage(),
                    ),
                  );
                },
                child: Container(
                  width: 41,
                  height: 41,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Image.asset('assets/image/emoji/List Pointers.jpg', fit: BoxFit.fill),
                ),
              ),
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/robot.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bad.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/error.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/Homeon.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 100,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Home',
                      style: TextStyle(
                        color: Color(0xFF49454F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        height: 1.45,
                        letterSpacing: 0.5,
                      ),
                    ),

                    const SizedBox(height: 16),
                    Text(
                      'RandomDish는 오늘은 뭐 먹지?라는 고민을 싹 털어주기 위해\n당신의 기분에 따라 음식을 랜덤으로 정해줍니다!',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        height: 1.43,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 412,
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '메뉴추천과 간단한 소개를 함께!',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 24,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 1.33,
                      ),
                    ),
                  ],
                ),
              ),

              // 최고일 때 이미지를 제일 처음 주소로 넣을 수 있지만 많은 사진을 넣으니 용량 문제로 컴퓨터가 다운되는 상황 발생하여, 아래에 이미지를 임의로 넣었습니다.
              SizedBox(height: 20),
              buildFoodCard('스테이크 & 와인', '스테이크에 와인 한 잔으로 분위기 UP.', 'assets/image/best/스테이크&와인.jpg'),
              SizedBox(height: 20),
              buildFoodCard('떡국', '따뜻하고 든든한 한 그릇.', 'assets/image/bad/떡국.jpg'),
              SizedBox(height: 20),
              buildFoodCard('마라탕', '얼얼하고 깊은 맛으로 스트레스를\n날려주는 중국식 매운탕.', 'assets/image/terrible/마라탕.jpg'),
              SizedBox(height: 20),
              buildFoodCard('삼겹살', '친구들과 함께 즐기는 고기의 풍미.', 'assets/image/good/삼겹살.jpg'),

              GestureDetector(
                onTap: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => MenuPage()),
                ),
                child: SizedBox(
                  width: double.infinity,
                  height: 28,
                  child: Text(
                    '더보기 ',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 22,
                      fontWeight: FontWeight.w400,
                      height: 1.27,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
//
class ResultPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 20),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,

            children: [
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/robot.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bad.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/error.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/home.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '최근 추천해드렸던 메뉴들(5개까지)',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 24,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 1.33,
                      ),
                    ),
                  ],
                ),
              ),

              // 최고일 때 이미지를 제일 처음 주소로 넣을 수 있지만 많은 사진을 넣으니 용량 문제로 컴퓨터가 다운되는 상황이 발생하여, 아래에 이미지를 임의로 넣었습니다.
              SizedBox(height: 20),
              buildFoodCard(resultNames[0], resultDescriptions[0], resultImagePaths[0]),
              SizedBox(height: 20),
              buildFoodCard(resultNames[1], resultDescriptions[1], resultImagePaths[1]),
              SizedBox(height: 20),
              buildFoodCard(resultNames[2], resultDescriptions[2], resultImagePaths[2]),
              SizedBox(height: 20),
              buildFoodCard(resultNames[3], resultDescriptions[3], resultImagePaths[3]),
              SizedBox(height: 20),
              buildFoodCard(resultNames[4], resultDescriptions[4], resultImagePaths[4]),

              GestureDetector(
                onTap: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                ),
                child: SizedBox(
                  width: double.infinity,
                  height: 28,
                  child: Text(
                    '홈으로 ',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 22,
                      fontWeight: FontWeight.w400,
                      height: 1.27,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
//



//
//
// 메뉴 페이지//
class MenuPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 32),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 22),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultPage(),
                    ),
                  );
                },
                child: Container(
                  width: 41,
                  height: 41,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Image.asset('assets/image/emoji/List Pointers.jpg', fit: BoxFit.fill),
                ),
              ),
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/robot.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bad.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/error.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/home.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 100,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '메뉴 더보기',
                      style: TextStyle(
                        color: Color(0xFF49454F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        height: 1.45,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      'RandomDish에서 추천해주는 음식 리스트들입니다.\n홈 버튼이나 뒤로가기 또는 표정을 눌러 선택해보세요!',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        height: 1.43,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ],
                ),
              ),

              //최고일 때
              SizedBox(height: 20),
              buildFoodCard('스테이크 & 와인', '스테이크에 와인 한 잔으로 분위기 UP.', 'assets/image/best/스테이크&와인.jpg'),
              SizedBox(height: 20),
              buildFoodCard('랍스터', '버터에 구워진 랍스터는 완벽한 선택.', 'assets/image/best/랍스터.jpg'),
              SizedBox(height: 20),
              buildFoodCard('초밥 오마카세', '셰프 추천 메뉴로 즐기는 고급 스시.', 'assets/image/best/초밥오마카세.jpg'),
              SizedBox(height: 20),
              buildFoodCard('트러플 크림 리조또', '트러플 향이 아는 이탈리아 요리.', 'assets/image/best/트러플크림리조또.jpg'),
              SizedBox(height: 20),
              buildFoodCard('대게찜', '신선한 대게의 단맛과 부드러운 식감.', 'assets/image/best/대게찜.jpg'),
              SizedBox(height: 20),
              buildFoodCard('양갈비', '풍미 가득한 양고기 스테이크.', 'assets/image/best/양갈비.jpg'),
              SizedBox(height: 20),
              buildFoodCard('한정식 코스', '한국 전통의 격조 높은 요리.', 'assets/image/best/한정식 코스.jpg'),
              SizedBox(height: 20),
              buildFoodCard('와규 샤브샤브', '고급 소고기로 즐기는 일본식 샤브샤브.', 'assets/image/best/와규 샤브샤브.jpg'),
              SizedBox(height: 20),
              buildFoodCard('뷔페', '다양한 음식을 마음껏 즐길 수 있는 고급\n뷔페에서의 만찬.', 'assets/image/best/뷔페.jpg'),
              SizedBox(height: 20),
              buildFoodCard('밀푀유 나베', '고기와 채소를 층층이 쌓은 일본식 요리.', 'assets/image/best/밀푀유나베.jpg'),

              //좋을 때
              SizedBox(height: 20),
              buildFoodCard('피자 & 파스타', '부담 없이 즐기는 이탈리안 음식.', 'assets/image/good/피자&파스타.jpg'),
              SizedBox(height: 20),
              buildFoodCard('치킨', '양념, 프라이드 등 기분 좋을 때 더 맛있게 \n먹을 수 있는 음식.', 'assets/image/good/치킨.jpg'),
              SizedBox(height: 20),
              buildFoodCard('돈가스', '겉바속촉의 일본식 요리.', 'assets/image/good/돈가스.jpg'),
              SizedBox(height: 20),
              buildFoodCard('분식세트', '국민 간식 콤보!.', 'assets/image/good/분식세트.jpg'),
              SizedBox(height: 20),
              buildFoodCard('불고기 덮밥', '고소한 맛이 기분을 더 좋게 만들어 줌.', 'assets/image/good/불고기 덮밥.jpg'),
              SizedBox(height: 20),
              buildFoodCard('냉면', '시원하고 깔끔한 맛.', 'assets/image/good/냉면.jpg'),
              SizedBox(height: 20),
              buildFoodCard('햄버거 세트', '패티와 바삭한 감자튀김이 완벽한 조합.', 'assets/image/good/햄버거 세트.jpg'),
              SizedBox(height: 20),
              buildFoodCard('타코 & 나쵸', '멕시코 스타일의 즐거운 음식.', 'assets/image/good/타코 & 나쵸.jpg'),
              SizedBox(height: 20),
              buildFoodCard('삼겹살', '친구들과 함께 즐기는 고기의 풍미.', 'assets/image/good/삼겹살.jpg'),
              SizedBox(height: 20),
              buildFoodCard('우동', '뜨끈하고 짭조름한 일본식 면 요리.', 'assets/image/good/우동.jpg'),

              //평범할 때
              SizedBox(height: 20),
              buildFoodCard('김치찌개', '뜨끈하고 깊은 맛이 마음을 따뜻하게.', 'assets/image/soso/김치찌개.jpg'),
              SizedBox(height: 20),
              buildFoodCard('된장찌개', '한국인의 소울푸드.', 'assets/image/soso/된장찌개.jpg'),
              SizedBox(height: 20),
              buildFoodCard('비빔밥', '다채로운 색감으로 하루에 생기를 더함.', 'assets/image/soso/비빔밥.jpg'),
              SizedBox(height: 20),
              buildFoodCard('치킨마요 덮밥', '간단하면서도 든든한 한 끼.', 'assets/image/soso/치킨마요 덮밥.jpg'),
              SizedBox(height: 20),
              buildFoodCard('짜장면', '맛있고 대중적인 중식.', 'assets/image/soso/짜장면.jpg'),
              SizedBox(height: 20),
              buildFoodCard('샌드위치', '간단하게 즐길 수 있는 한 끼.', 'assets/image/soso/샌드위치.jpg'),
              SizedBox(height: 20),
              buildFoodCard('순댓국', '진한 국물 요리로 속을 든든하게.', 'assets/image/soso/순댓국.jpg'),
              SizedBox(height: 20),
              buildFoodCard('라면', '간단하지만 만족스러운 선택.', 'assets/image/soso/라면.jpg'),
              SizedBox(height: 20),
              buildFoodCard('김치볶음밥', '볶음 김치와 밥이 어우러진 간단한 한 끼.', 'assets/image/soso/김치볶음밥.jpg'),
              SizedBox(height: 20),
              buildFoodCard('닭갈비', '매콤한 양념에 볶은 닭고기와 채소 요리.', 'assets/image/soso/닭갈비.jpg'),

              //별로일 때
              SizedBox(height: 20),
              buildFoodCard('죽', '속을 따뜻하게 해주는 부드러운 음식.', 'assets/image/bad/죽.jpg'),
              SizedBox(height: 20),
              buildFoodCard('삼계탕', '몸과 마음을 달래주는 보양식.', 'assets/image/bad/삼계탕.jpg'),
              SizedBox(height: 20),
              buildFoodCard('카레', '향긋하고 달콤한 맛으로 기분 전환.', 'assets/image/bad/카레.jpg'),
              SizedBox(height: 20),
              buildFoodCard('떡국', '따뜻하고 든든한 한 그릇.', 'assets/image/bad/떡국.jpg'),
              SizedBox(height: 20),
              buildFoodCard('팟타이', '부드럽고 달콤한 태국 요리.', 'assets/image/bad/팟타이.jpg'),
              SizedBox(height: 20),
              buildFoodCard('오므라이스', '부드러운 달걀과 케첩이 위로를 줌.', 'assets/image/bad/오므라이스.jpg'),
              SizedBox(height: 20),
              buildFoodCard('순두부찌개', '부드럽고 따뜻한 국물 요리.', 'assets/image/bad/순두부찌개.jpg'),
              SizedBox(height: 20),
              buildFoodCard('토스트', '간단하면서 달콤하게 즐길 수 있는 메뉴.', 'assets/image/bad/토스트.jpg'),
              SizedBox(height: 20),
              buildFoodCard('카스테라 & 우유', '폭신폭신한 식감으로 편안한 느낌.', 'assets/image/bad/카스테라 & 우유.jpg'),
              SizedBox(height: 20),
              buildFoodCard('따뜻한 차와 과자', '마음의 안정을 위한 티타임.', 'assets/image/bad/따뜻한 차와 과자.jpg'),

              //최악일 때
              SizedBox(height: 20),
              buildFoodCard('소고기미역국', '담백하고 깔끔한 맛으로 속을 풀어줌.', 'assets/image/terrible/소고기 미역국.jpg'),
              SizedBox(height: 20),
              buildFoodCard('설렁탕', '사골 국물에 밥을 곁들여 든든한 한 끼.', 'assets/image/terrible/설렁탕.jpg'),
              SizedBox(height: 20),
              buildFoodCard('계란찜', '촉촉하고 부드러운 맛으로 편안함.', 'assets/image/terrible/계란찜.jpg'),
              SizedBox(height: 20),
              buildFoodCard('바나나 & 우유', '소화가 잘 되며 스트레스에 큰 효과!', 'assets/image/terrible/바나나 & 우유.jpg'),
              SizedBox(height: 20),
              buildFoodCard('콩나물국밥', '개운한 국물로 속을 풀어주는 전통 음식.', 'assets/image/terrible/콩나물국밥.jpg'),
              SizedBox(height: 20),
              buildFoodCard('콘스프', '따뜻하고 달콤한 맛의 간단한 음식.', 'assets/image/terrible/콘스프.jpg'),
              SizedBox(height: 20),
              buildFoodCard('요거트 볼', '건강하면서도 상쾌한 느낌을 주는 음식.', 'assets/image/terrible/요거트 볼.jpg'),
              SizedBox(height: 20),
              buildFoodCard('마라탕', '얼얼하고 깊은 맛으로 스트레스를\n날려주는 중국식 매운탕.', 'assets/image/terrible/마라탕.jpg'),
              SizedBox(height: 20),
              buildFoodCard('짬뽕', '진한 국물과 매운맛이 어우러져\n스트레스를 풀기에 딱 좋은 메뉴.', 'assets/image/terrible/짬뽕.jpg'),
              SizedBox(height: 20),
              buildFoodCard('불족발', '족발에 매운 양념을 더해 쫄깃한 식감과\n매운맛을 함께 즐김.', 'assets/image/terrible/불족발.jpg'),

            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
//
//
// 메뉴 페이지//



//
//
// 두번째 페이지//
class bestPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 32),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 22),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultPage(),
                    ),
                  );
                },
                child: Container(
                  width: 41,
                  height: 41,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Image.asset('assets/image/emoji/List Pointers.jpg', fit: BoxFit.fill),
                ),
              ),
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmileon.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/robot.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bad.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/error.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/home.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 100,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '최고의 기분!!!',
                      style: TextStyle(
                        color: Color(0xFF49454F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        height: 1.45,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '기분이 매우 좋은 날인 것 같아요!\n오늘은 특별한 음식으로 행복한 분위기를 즐겨보세요!',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        height: 1.43,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 412,
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '랜덤추첨 클릭',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 24,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 1.33,
                      ),
                    ),
                GestureDetector(
                  onTap: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => best2Page(),
                      ),
                    );
                    count+=1;
                  },
                  child: Container(
                      width: 32,
                      height: 32,
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(),
                      child: Image.asset('assets/image/emoji/go.jpg', fit: BoxFit.fill),
                    ),
                ),
                  ],
                ),
              ),

              //최고일 때
              SizedBox(height: 20),
              buildFoodCard('스테이크 & 와인', '스테이크에 와인 한 잔으로 분위기 UP.', 'assets/image/best/스테이크&와인.jpg'),
              SizedBox(height: 20),
              buildFoodCard('랍스터', '버터에 구워진 랍스터는 완벽한 선택.', 'assets/image/best/랍스터.jpg'),
              SizedBox(height: 20),
              buildFoodCard('초밥 오마카세', '셰프 추천 메뉴로 즐기는 고급 스시.', 'assets/image/best/초밥오마카세.jpg'),
              SizedBox(height: 20),
              buildFoodCard('밀푀유 나베', '고기와 채소를 층층이 쌓은 일본식 요리.', 'assets/image/best/밀푀유나베.jpg'),


            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
//
// 두번째 페이지//



//
//
// 세번째 페이지//
class goodPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 32),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 22),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultPage(),
                    ),
                  );
                },
                child: Container(
                  width: 41,
                  height: 41,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Image.asset('assets/image/emoji/List Pointers.jpg', fit: BoxFit.fill),
                ),
              ),
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smileon.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/robot.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bad.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/error.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/home.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 100,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '좋은 기분!',
                      style: TextStyle(
                        color: Color(0xFF49454F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        height: 1.45,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '기분이 좋아보이네요!\n이런 날에는 가벼운 마음으로 즐길 수 있는 메뉴는 어떤가요?',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        height: 1.43,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 412,
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '랜덤추첨 클릭',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 24,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 1.33,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => good2Page(),
                          ),
                        );
                        count+=1;
                      },
                      child: Container(
                        width: 32,
                        height: 32,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/go.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),

              //좋을 때
              SizedBox(height: 20),
              buildFoodCard('피자 & 파스타', '부담 없이 즐기는 이탈리안 음식.', 'assets/image/good/피자&파스타.jpg'),
              SizedBox(height: 20),
              buildFoodCard('치킨', '양념, 프라이드 등 기분 좋을 때 더 맛있게 \n먹을 수 있는 음식.', 'assets/image/good/치킨.jpg'),
              SizedBox(height: 20),
              buildFoodCard('돈가스', '겉바속촉의 일본식 요리.', 'assets/image/good/돈가스.jpg'),
              SizedBox(height: 20),
              buildFoodCard('분식세트', '국민 간식 콤보!.', 'assets/image/good/분식세트.jpg'),


            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
//
// 세번째 페이지//


//
//
// 네번째 페이지//
class sosoPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 32),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 22),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultPage(),
                    ),
                  );
                },
                child: Container(
                  width: 41,
                  height: 41,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Image.asset('assets/image/emoji/List Pointers.jpg', fit: BoxFit.fill),
                ),
              ),
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/roboton.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bad.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/error.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/home.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 100,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '평범한 날',
                      style: TextStyle(
                        color: Color(0xFF49454F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        height: 1.45,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '오늘같이 평범한 날도 조금은 특별하게 만들어주는 음식은\n어떤가요? 오늘도 무난하게 잘 흘러가면 좋겠어요 :)',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        height: 1.43,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 412,
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '랜덤추첨 클릭',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 24,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 1.33,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => soso2Page(),
                          ),
                        );
                        count+=1;
                      },
                      child: Container(
                        width: 32,
                        height: 32,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/go.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),

              //평범할 때
              SizedBox(height: 20),
              buildFoodCard('김치찌개', '뜨끈하고 깊은 맛이 마음을 따뜻하게.', 'assets/image/soso/김치찌개.jpg'),
              SizedBox(height: 20),
              buildFoodCard('된장찌개', '한국인의 소울푸드.', 'assets/image/soso/된장찌개.jpg'),
              SizedBox(height: 20),
              buildFoodCard('비빔밥', '다채로운 색감으로 하루에 생기를 더함.', 'assets/image/soso/비빔밥.jpg'),
              SizedBox(height: 20),
              buildFoodCard('짜장면', '맛있고 대중적인 중식.', 'assets/image/soso/짜장면.jpg'),


            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
//
// 네번째 페이지//



//
//
// 다섯번째 페이지//
class badPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 32),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 22),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultPage(),
                    ),
                  );
                },
                child: Container(
                  width: 41,
                  height: 41,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Image.asset('assets/image/emoji/List Pointers.jpg', fit: BoxFit.fill),
                ),
              ),
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/robot.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/badon.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/error.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/home.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 100,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '기분 별로..',
                      style: TextStyle(
                        color: Color(0xFF49454F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        height: 1.45,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '기분이 생각보다 별로인 날이 늘 있어요\n그럴 때 편안함을 줄 수 있는 음식은 어떨까요?',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        height: 1.43,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 412,
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '랜덤추첨 클릭',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 24,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 1.33,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bad2Page(),
                          ),
                        );
                        count+=1;
                      },
                      child: Container(
                        width: 32,
                        height: 32,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/go.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),

              //별로일 때
              SizedBox(height: 20),
              buildFoodCard('죽', '속을 따뜻하게 해주는 부드러운 음식.', 'assets/image/bad/죽.jpg'),
              SizedBox(height: 20),
              buildFoodCard('삼계탕', '몸과 마음을 달래주는 보양식.', 'assets/image/bad/삼계탕.jpg'),
              SizedBox(height: 20),
              buildFoodCard('카레', '향긋하고 달콤한 맛으로 기분 전환.',  'assets/image/bad/카레.jpg'),
              SizedBox(height: 20),
              buildFoodCard('떡국', '따뜻하고 든든한 한 그릇.', 'assets/image/bad/떡국.jpg'),

            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
//
// 다섯번째 페이지//


//
//
// 여섯번째 페이지//
class terriblePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 32),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 22),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultPage(),
                    ),
                  );
                },
                child: Container(
                  width: 41,
                  height: 41,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Image.asset('assets/image/emoji/List Pointers.jpg', fit: BoxFit.fill),
                ),
              ),
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/robot.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bad.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/erroron.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/home.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 100,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '기분 최악.',
                      style: TextStyle(
                        color: Color(0xFF49454F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        height: 1.45,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '오늘 기분이 많이 안 좋으셨나봐요.\n위로와 치유가 필요한 순간에, 필요한 음식을 골라보세요.)',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        height: 1.43,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 412,
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '랜덤추첨 클릭',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 24,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 1.33,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terrible2Page(),
                          ),
                        );
                        count+=1;
                      },
                      child: Container(
                        width: 32,
                        height: 32,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/go.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),

              //최악일 때
              SizedBox(height: 20),
              buildFoodCard('소고기미역국', '담백하고 깔끔한 맛으로 속을 풀어줌.', 'assets/image/terrible/소고기 미역국.jpg'),
              SizedBox(height: 20),
              buildFoodCard('설렁탕', '사골 국물에 밥을 곁들여 든든한 한 끼.', 'assets/image/terrible/설렁탕.jpg'),
              SizedBox(height: 20),
              buildFoodCard('계란찜', '촉촉하고 부드러운 맛으로 편안함.', 'assets/image/terrible/계란찜.jpg'),
              SizedBox(height: 20),
              buildFoodCard('바나나 & 우유', '소화가 잘 되며 스트레스에 큰 효과!', 'assets/image/terrible/바나나 & 우유.jpg'),

            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
//

// 일곱번째 페이지//
class best2Page extends StatelessWidget {
  final int randomIndex = Random().nextInt(10);
  best2Page()
  {
    resultNames[count%5]=bestNames[randomIndex];
    resultDescriptions[count%5]=bestDescriptions[randomIndex];
    resultImagePaths[count%5]=bestImagePaths[randomIndex];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 32),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 22),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultPage(),
                    ),
                  );
                },
                child: Container(
                  width: 41,
                  height: 41,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Image.asset('assets/image/emoji/List Pointers.jpg', fit: BoxFit.fill),
                ),
              ),
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmileon.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/robot.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bad.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/error.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/home.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 100,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '최고의 기분!!!',
                      style: TextStyle(
                        color: Color(0xFF49454F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        height: 1.45,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '기분이 매우 좋은 날인 것 같아요!\n오늘은 특별한 음식으로 행복한 분위기를 즐겨보세요!',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        height: 1.43,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                width: 412,
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '랜덤추첨 결과는?',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 24,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 1.33,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 412,
                height: 375,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      height: 230,
                      decoration: ShapeDecoration(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 370,
                                  height: 230,
                                  decoration: ShapeDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(bestImagePaths[randomIndex]),
                                      fit: BoxFit.fill,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      height: 66,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 55,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: double.infinity,
                                  child: Text(
                                    ('오늘은 '+ bestNames[randomIndex]+'(이)다!'),
                                    style: TextStyle(
                                      color: Color(0xFF1D1B20),
                                      fontSize: 22,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 1.27,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                SizedBox(
                                  width: double.infinity,
                                  child: Text(
                                    bestDescriptions[randomIndex],
                                    style: TextStyle(
                                      color: Color(0xFF49454F),
                                      fontSize: 14,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 1.43,
                                      letterSpacing: 0.25,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      height: 47,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 47,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 4),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => bestPage(),
                                      ),
                                    );
                                  },
                                  child: Container(
                                    width: 34,
                                    height: 34,
                                    clipBehavior: Clip.antiAlias,
                                    decoration: BoxDecoration(),
                                    child: Image.asset('assets/image/emoji/replay.jpg', fit: BoxFit.fill),
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () => Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(builder: (context) => BestFoodImagePage(randomIndex: randomIndex)),
                                  ),
                                  child: SizedBox(
                                    width: double.infinity,
                                    height: 28,
                                    child: Text(
                                      '더보기 ',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 22,
                                        fontWeight: FontWeight.w400,
                                        height: 1.27,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),


            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
//
// 일곱번째 페이지//



//
//
// 여덟번째 페이지//
class good2Page extends StatelessWidget {
  final int randomIndex = Random().nextInt(10);
  good2Page()
  {
    resultNames[count%5]=goodNames[randomIndex];
    resultDescriptions[count%5]=goodDescriptions[randomIndex];
    resultImagePaths[count%5]=goodImagePaths[randomIndex];
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 32),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 22),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultPage(),
                    ),
                  );
                },
                child: Container(
                  width: 41,
                  height: 41,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Image.asset('assets/image/emoji/List Pointers.jpg', fit: BoxFit.fill),
                ),
              ),
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smileon.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/robot.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bad.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/error.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/home.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 100,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '좋은 기분!',
                      style: TextStyle(
                        color: Color(0xFF49454F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        height: 1.45,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '오늘 같은 날에는 당연히 이 음식이죠!\n오늘 이 음식은 어떤가요?',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        height: 1.43,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                width: 412,
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '랜덤추첨 결과는?',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 24,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 1.33,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 412,
                height: 375,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      height: 230,
                      decoration: ShapeDecoration(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 370,
                                  height: 230,
                                  decoration: ShapeDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(goodImagePaths[randomIndex]),
                                      fit: BoxFit.fill,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      height: 66,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 55,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: double.infinity,
                                  child: Text(
                                    ('오늘은 '+ goodNames[randomIndex]+'(이)다!'),
                                    style: TextStyle(
                                      color: Color(0xFF1D1B20),
                                      fontSize: 22,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 1.27,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                SizedBox(
                                  width: double.infinity,
                                  child: Text(
                                    goodDescriptions[randomIndex],
                                    style: TextStyle(
                                      color: Color(0xFF49454F),
                                      fontSize: 14,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 1.43,
                                      letterSpacing: 0.25,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      height: 47,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 47,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 4),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => goodPage(),
                                      ),
                                    );
                                  },
                                  child: Container(
                                    width: 34,
                                    height: 34,
                                    clipBehavior: Clip.antiAlias,
                                    decoration: BoxDecoration(),
                                    child: Image.asset('assets/image/emoji/replay.jpg', fit: BoxFit.fill),
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () => Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(builder: (context) => goodFoodImagePage(randomIndex: randomIndex)),
                                  ),
                                  child: SizedBox(
                                    width: double.infinity,
                                    height: 28,
                                    child: Text(
                                      '더보기 ',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 22,
                                        fontWeight: FontWeight.w400,
                                        height: 1.27,
                                      ),
                                    ),
                                  ),
                                ),

                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
//
// 여덟번째 페이지//



//
//
// 아홉번째 페이지//
class soso2Page extends StatelessWidget {
  final int randomIndex = Random().nextInt(10);
  soso2Page()
  {
    resultNames[count%5]=sosoNames[randomIndex];
    resultDescriptions[count%5]=sosoDescriptions[randomIndex];
    resultImagePaths[count%5]=sosoImagePaths[randomIndex];
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 32),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 22),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultPage(),
                    ),
                  );
                },
                child: Container(
                  width: 41,
                  height: 41,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Image.asset('assets/image/emoji/List Pointers.jpg', fit: BoxFit.fill),
                ),
              ),
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/roboton.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bad.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/error.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/home.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 100,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '평범한 날',
                      style: TextStyle(
                        color: Color(0xFF49454F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        height: 1.45,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '오늘같이 평범한 날도 조금은 특별하게 만들어주는 음식은\n어떤가요? 오늘도 무난하게 잘 흘러가면 좋겠어요 :)',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        height: 1.43,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                width: 412,
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '랜덤추첨 결과는?',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 24,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 1.33,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 412,
                height: 375,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      height: 230,
                      decoration: ShapeDecoration(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 370,
                                  height: 230,
                                  decoration: ShapeDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(sosoImagePaths[randomIndex]),
                                      fit: BoxFit.fill,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      height: 66,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 55,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: double.infinity,
                                  child: Text(
                                    ('오늘은 '+ sosoNames[randomIndex]+'(이)다!'),
                                    style: TextStyle(
                                      color: Color(0xFF1D1B20),
                                      fontSize: 22,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 1.27,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                SizedBox(
                                  width: double.infinity,
                                  child: Text(
                                    sosoDescriptions[randomIndex],
                                    style: TextStyle(
                                      color: Color(0xFF49454F),
                                      fontSize: 14,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 1.43,
                                      letterSpacing: 0.25,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      height: 47,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 47,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 4),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => sosoPage(),
                                      ),
                                    );
                                  },
                                  child: Container(
                                    width: 34,
                                    height: 34,
                                    clipBehavior: Clip.antiAlias,
                                    decoration: BoxDecoration(),
                                    child: Image.asset('assets/image/emoji/replay.jpg', fit: BoxFit.fill),
                                  ),
                                ),

                                GestureDetector(
                                  onTap: () => Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(builder: (context) => sosoFoodImagePage(randomIndex: randomIndex)),
                                  ),
                                  child: SizedBox(
                                    width: double.infinity,
                                    height: 28,
                                    child: Text(
                                      '더보기 ',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 22,
                                        fontWeight: FontWeight.w400,
                                        height: 1.27,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
//
// 아홉번째 페이지//


//
//
// 열번째 페이지//
class bad2Page extends StatelessWidget {
  final int randomIndex = Random().nextInt(10);
  bad2Page()
  {
    resultNames[count%5]=badNames[randomIndex];
    resultDescriptions[count%5]=badDescriptions[randomIndex];
    resultImagePaths[count%5]=badImagePaths[randomIndex];
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 20),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,

            children: [
              const SizedBox(width: 30),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultPage(),
                    ),
                  );
                },
                child: Container(
                  width: 41,
                  height: 41,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Image.asset('assets/image/emoji/List Pointers.jpg', fit: BoxFit.fill),
                ),
              ),
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/robot.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/badon.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/error.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/home.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 100,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '기분 별로..',
                      style: TextStyle(
                        color: Color(0xFF49454F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        height: 1.45,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '기분이 생각보다 별로인 날이 늘 있어요\n그럴 때 편안함을 줄 수 있는 음식은 어떨까요?',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        height: 1.43,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                width: 412,
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '랜덤추첨 결과는?',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 24,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 1.33,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 412,
                height: 375,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      height: 230,
                      decoration: ShapeDecoration(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 370,
                                  height: 230,
                                  decoration: ShapeDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(badImagePaths[randomIndex]),
                                      fit: BoxFit.fill,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      height: 66,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 55,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: double.infinity,
                                  child: Text(
                                    ('오늘은 '+ badNames[randomIndex]+'(이)다!'),
                                    style: TextStyle(
                                      color: Color(0xFF1D1B20),
                                      fontSize: 22,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 1.27,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                SizedBox(
                                  width: double.infinity,
                                  child: Text(
                                    badDescriptions[randomIndex],
                                    style: TextStyle(
                                      color: Color(0xFF49454F),
                                      fontSize: 14,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 1.43,
                                      letterSpacing: 0.25,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      height: 47,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 47,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 4),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => badPage(),
                                      ),
                                    );
                                  },
                                  child: Container(
                                    width: 34,
                                    height: 34,
                                    clipBehavior: Clip.antiAlias,
                                    decoration: BoxDecoration(),
                                    child: Image.asset('assets/image/emoji/replay.jpg', fit: BoxFit.fill),
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () => Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(builder: (context) => badFoodImagePage(randomIndex: randomIndex)),
                                  ),
                                  child: SizedBox(
                                    width: double.infinity,
                                    height: 28,
                                    child: Text(
                                      '더보기 ',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 22,
                                        fontWeight: FontWeight.w400,
                                        height: 1.27,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
//
// 열번째 페이지//



//
//
// 열번째 페이지//
class terrible2Page extends StatelessWidget {
  final int randomIndex = Random().nextInt(10);
  terrible2Page()
  {
    resultNames[count%5]=terribleNames[randomIndex];
    resultDescriptions[count%5]=terribleDescriptions[randomIndex];
    resultImagePaths[count%5]=terribleImagePaths[randomIndex];
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RandomDish'),
        backgroundColor: Color(0xFFFEF7FF),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.only(bottom: 32),
          decoration: BoxDecoration(
            color: Color(0xFFFEF7FF),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 25),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ResultPage(),
                    ),
                  );
                },
                child: Container(
                  width: 41,
                  height: 41,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Image.asset('assets/image/emoji/List Pointers.jpg', fit: BoxFit.fill),
                ),
              ),
              // 타이틀
              Container(
                width: 412,
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Color(0xFFFEF7FF)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bestPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bigsmile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => goodPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/smile.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sosoPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/robot.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => badPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/bad.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => terriblePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/erroron.jpg', fit: BoxFit.fill),
                      ),
                    ),
                    const SizedBox(width: 22),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 41,
                        height: 41,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Image.asset('assets/image/emoji/home.jpg', fit: BoxFit.fill),
                      ),
                    ),
                  ],
                ),
              ),
              // 설명 텍스트
              Container(
                width: 412,
                height: 100,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '기분 최악.',
                      style: TextStyle(
                        color: Color(0xFF49454F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        height: 1.45,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '오늘 기분이 많이 안 좋으셨나봐요.\n위로와 치유가 필요한 순간에, 필요한 음식을 골라보세요.',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        height: 1.43,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                width: 412,
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '랜덤추첨 결과는?',
                      style: TextStyle(
                        color: Color(0xFF1D1B20),
                        fontSize: 24,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 1.33,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 412,
                height: 375,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      height: 230,
                      decoration: ShapeDecoration(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 370,
                                  height: 230,
                                  decoration: ShapeDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(terribleImagePaths[randomIndex]),
                                      fit: BoxFit.fill,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      height: 66,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 55,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: double.infinity,
                                  child: Text(
                                    ('오늘은 '+ terribleNames[randomIndex]+'(이)다!'),
                                    style: TextStyle(
                                      color: Color(0xFF1D1B20),
                                      fontSize: 22,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 1.27,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                SizedBox(
                                  width: double.infinity,
                                  child: Text(
                                    terribleDescriptions[randomIndex],
                                    style: TextStyle(
                                      color: Color(0xFF49454F),
                                      fontSize: 14,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 1.43,
                                      letterSpacing: 0.25,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      height: 47,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 47,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 4),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => terriblePage(),
                                      ),
                                    );
                                  },
                                  child: Container(
                                    width: 34,
                                    height: 34,
                                    clipBehavior: Clip.antiAlias,
                                    decoration: BoxDecoration(),
                                    child: Image.asset('assets/image/emoji/replay.jpg', fit: BoxFit.fill),
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () => Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(builder: (context) => terribleFoodImagePage(randomIndex: randomIndex)),
                                  ),
                                  child: SizedBox(
                                    width: double.infinity,
                                    height: 28,
                                    child: Text(
                                      '더보기 ',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 22,
                                        fontWeight: FontWeight.w400,
                                        height: 1.27,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }

  Widget buildFoodCard(String title, String description, String imageUrl) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFF1D1B20),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Color(0xFF49454F),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.43,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
//
// 열한번째 페이지//


//
//기분 최고일 때 음식 서버 연결
class BestFoodImagePage extends StatefulWidget {
  @override
  final int randomIndex;
  BestFoodImagePage({this.randomIndex=0});
  _BestFoodImagePageState createState() => _BestFoodImagePageState();
}

class _BestFoodImagePageState extends State<BestFoodImagePage> {
  final List<String> bestNames = [
    '스테이크 & 와인', '랍스터', '초밥 오마카세', '트러플 크림 리조또', '대게찜',
    '양갈비', '한정식 코스', '와규 샤브샤브', '뷔페', '밀푀유 나베'
  ];


  String foodName = '';
  String? imageBase64;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    // 랜덤 음식 선택
    foodName = bestNames[widget.randomIndex];
  }

  // 서버에서 이미지 가져오기
  Future<void> _fetchFoodImage() async {
    setState(() {
      isLoading = true;
      imageBase64 = null;
    });

    try {
      final response = await http.get(
        Uri.parse('http://127.0.0.1:5000/get_food_image?food_name=$foodName'),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        setState(() {
          imageBase64 = data['image'];
          isLoading = false;
        });
      } else {
        throw Exception('Failed to load image');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('랜덤 음식: $foodName'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                ),
                child: SizedBox(
                  width: double.infinity,
                  height: 28,
                  child: Text(
                    '저를 눌러 홈으로 돌아가세요!!!\n\n\n',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 22,
                      fontWeight: FontWeight.w400,
                      height: 1.27,
                    ),
                  ),
                ),
              ),
              Text(
                '오늘의 랜덤 음식은: $foodName',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _fetchFoodImage,
                child: Text('더보기'),
              ),
              SizedBox(height: 20),
              if (isLoading)
                CircularProgressIndicator()
              else if (imageBase64 != null)
                Image.memory(
                  base64Decode(imageBase64!),
                  fit: BoxFit.cover,
                )
              else
                Text(''),
            ],
          ),
        ),
      ),
    );
  }
}



//
//기분 좋을 때 음식 서버 연결
class goodFoodImagePage extends StatefulWidget {
  @override
  final int randomIndex;
  goodFoodImagePage({this.randomIndex=0});
  _goodFoodImagePageState createState() => _goodFoodImagePageState();
}

class _goodFoodImagePageState extends State<goodFoodImagePage> {
  final List<String> goodNames = [
  '피자 & 파스타', '치킨', '돈가스', '분식세트', '불고기 덮밥',
  '냉면', '햄버거 세트', '타코 & 나쵸', '삼겹살', '우동'
  ];


  String foodName = '';
  String? imageBase64;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    // 랜덤 음식 선택
    foodName = goodNames[widget.randomIndex];
  }

  // 서버에서 이미지 가져오기
  Future<void> _fetchFoodImage() async {
    setState(() {
      isLoading = true;
      imageBase64 = null;
    });

    try {
      final response = await http.get(
        Uri.parse('http://127.0.0.1:5000/get_food_image?food_name=$foodName'),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        setState(() {
          imageBase64 = data['image'];
          isLoading = false;
        });
      } else {
        throw Exception('Failed to load image');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('랜덤 음식: $foodName'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                ),
                child: SizedBox(
                  width: double.infinity,
                  height: 28,
                  child: Text(
                    '저를 눌러 홈으로 돌아가세요!!!\n\n\n',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 22,
                      fontWeight: FontWeight.w400,
                      height: 1.27,
                    ),
                  ),
                ),
              ),
              Text(
                '오늘의 랜덤 음식은: $foodName',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _fetchFoodImage,
                child: Text('더보기'),
              ),
              SizedBox(height: 20),
              if (isLoading)
                CircularProgressIndicator()
              else if (imageBase64 != null)
                Image.memory(
                  base64Decode(imageBase64!),
                  fit: BoxFit.cover,
                )
              else
                Text(''),
            ],
          ),
        ),
      ),
    );
  }
}


//
//평범할 때 음식 서버 연결
class sosoFoodImagePage extends StatefulWidget {
  @override
  final int randomIndex;
  sosoFoodImagePage({this.randomIndex=0});
  _sosoFoodImagePageState createState() => _sosoFoodImagePageState();
}

class _sosoFoodImagePageState extends State<sosoFoodImagePage> {
  final List<String> sosoNames = [
  '김치찌개', '된장찌개', '비빔밥', '치킨마요 덮밥', '짜장면',
  '샌드위치', '순댓국', '라면', '김치볶음밥', '닭갈비'
  ];


  String foodName = '';
  String? imageBase64;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    // 랜덤 음식 선택
    foodName = sosoNames[widget.randomIndex];
  }

  // 서버에서 이미지 가져오기
  Future<void> _fetchFoodImage() async {
    setState(() {
      isLoading = true;
      imageBase64 = null;
    });

    try {
      final response = await http.get(
        Uri.parse('http://127.0.0.1:5000/get_food_image?food_name=$foodName'),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        setState(() {
          imageBase64 = data['image'];
          isLoading = false;
        });
      } else {
        throw Exception('Failed to load image');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('랜덤 음식: $foodName'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                ),
                child: SizedBox(
                  width: double.infinity,
                  height: 28,
                  child: Text(
                    '저를 눌러 홈으로 돌아가세요!!!\n\n\n',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 22,
                      fontWeight: FontWeight.w400,
                      height: 1.27,
                    ),
                  ),
                ),
              ),
              Text(
                '오늘의 랜덤 음식은: $foodName',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _fetchFoodImage,
                child: Text('더보기'),
              ),
              SizedBox(height: 20),
              if (isLoading)
                CircularProgressIndicator()
              else if (imageBase64 != null)
                Image.memory(
                  base64Decode(imageBase64!),
                  fit: BoxFit.cover,
                )
              else
                Text(''),
            ],
          ),
        ),
      ),
    );
  }
}


//
//기분 별로일 때 음식 서버 연결
class badFoodImagePage extends StatefulWidget {
  @override
  final int randomIndex;
  badFoodImagePage({this.randomIndex=0});
  _badFoodImagePageState createState() => _badFoodImagePageState();
}

class _badFoodImagePageState extends State<badFoodImagePage> {
  final List<String> badNames = [
    '죽', '삼계탕', '카레', '떡국', '팟타이',
    '오므라이스', '순두부찌개', '토스트', '카스테라 & 우유', '따뜻한 차와 과자'
  ];


  String foodName = '';
  String? imageBase64;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    // 랜덤 음식 선택
    foodName = badNames[widget.randomIndex];
  }

  // 서버에서 이미지 가져오기
  Future<void> _fetchFoodImage() async {
    setState(() {
      isLoading = true;
      imageBase64 = null;
    });

    try {
      final response = await http.get(
        Uri.parse('http://127.0.0.1:5000/get_food_image?food_name=$foodName'),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        setState(() {
          imageBase64 = data['image'];
          isLoading = false;
        });
      } else {
        throw Exception('Failed to load image');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('랜덤 음식: $foodName'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                ),
                child: SizedBox(
                  width: double.infinity,
                  height: 28,
                  child: Text(
                    '저를 눌러 홈으로 돌아가세요!!!\n\n\n',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 22,
                      fontWeight: FontWeight.w400,
                      height: 1.27,
                    ),
                  ),
                ),
              ),
              Text(
                '오늘의 랜덤 음식은: $foodName',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _fetchFoodImage,
                child: Text('더보기'),
              ),
              SizedBox(height: 20),
              if (isLoading)
                CircularProgressIndicator()
              else if (imageBase64 != null)
                Image.memory(
                  base64Decode(imageBase64!),
                  fit: BoxFit.cover,
                )
              else
                Text(''),
            ],
          ),
        ),
      ),
    );
  }
}





//
//기분최악일 때 음식 서버 연결
class terribleFoodImagePage extends StatefulWidget {
  @override
  final int randomIndex;
  terribleFoodImagePage({this.randomIndex=0});
  _terribleFoodImagePageState createState() => _terribleFoodImagePageState();
}

class _terribleFoodImagePageState extends State<terribleFoodImagePage> {
  final List<String> terribleNames = [
    '소고기미역국', '설렁탕', '계란찜', '바나나 & 우유', '콩나물국밥',
    '콘스프', '요거트 볼', '마라탕', '짬뽕', '불족발'
  ];


  String foodName = '';
  String? imageBase64;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    // 랜덤 음식 선택
    foodName = terribleNames[widget.randomIndex];
  }

  // 서버에서 이미지 가져오기
  Future<void> _fetchFoodImage() async {
    setState(() {
      isLoading = true;
      imageBase64 = null;
    });

    try {
      final response = await http.get(
        Uri.parse('http://127.0.0.1:5000/get_food_image?food_name=$foodName'),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        setState(() {
          imageBase64 = data['image'];
          isLoading = false;
        });
      } else {
        throw Exception('Failed to load image');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('랜덤 음식: $foodName'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                ),
                child: SizedBox(
                  width: double.infinity,
                  height: 28,
                  child: Text(
                    '저를 눌러 홈으로 돌아가세요!!!\n\n\n',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 22,
                      fontWeight: FontWeight.w400,
                      height: 1.27,
                    ),
                  ),
                ),
              ),
              Text(
                '오늘의 랜덤 음식은: $foodName',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _fetchFoodImage,
                child: Text('더보기'),
              ),
              SizedBox(height: 20),
              if (isLoading)
                CircularProgressIndicator()
              else if (imageBase64 != null)
                Image.memory(
                  base64Decode(imageBase64!),
                  fit: BoxFit.cover,
                )
              else
                Text(''),
            ],
          ),
        ),
      ),
    );
  }
}

