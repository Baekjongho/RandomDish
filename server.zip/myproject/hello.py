from flask import Flask, jsonify, request
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from PIL import Image
import io
import base64
import os
import time
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

def capture_search_page(food_name):
    # Chrome 설정
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')

    # WebDriver 초기화
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    driver.get(f"https://search.naver.com/search.naver?ssc=tab.image.all&where=image&sm=tab_jum&query={food_name}")

    # 뷰포트 크기 설정 (가로: 1920, 세로: 1080)
    driver.set_window_size(1920, 1080)

    time.sleep(5)

    # 스크린샷 캡처
    screenshot = driver.get_screenshot_as_png()
    driver.quit()

    # 스크린샷을 PIL 이미지로 변환
    image = Image.open(io.BytesIO(screenshot))
    image_buffer = io.BytesIO()
    image.save(image_buffer, format="PNG")
    image_buffer.seek(0)

    # Base64로 인코딩
    return base64.b64encode(image_buffer.getvalue()).decode('utf-8')

@app.route('/get_food_image', methods=['GET'])
def get_food_image():
    food_name = request.args.get('food_name')
    if not food_name:
        return jsonify({'error': 'Food name is required'}), 400

    try:
        # 이미지 캡처 및 Base64 반환
        image_base64 = capture_search_page(food_name)
        return jsonify({'image': image_base64})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
